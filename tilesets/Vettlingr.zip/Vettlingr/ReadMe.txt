Thank you for downloading Vettlingrs Tieset. 1.2

This is an beta version, its features are subject to change. A lot of the assets are still placeholders from other sets.

Installation For Starter Pack.

Simply Move the Vettlingr Folder into LNP/graphics. 
Then update your graphics settings and saves in the Launcher.
If Tiles appear strange or wonky, manually update your saves raws with the raws in 
LNP/graphics/vettlingr/raw/objects

Manual Installation:
Copy the files in vettlingr/data/art and init as well as vettlingr/graphics and vettlingr/raws/objects into their corresponding folders.

Useof sprites outside of DF is prohibited unless you have special permission.

Changelog
1.2: Added Further furniture variations, as well as new sprites for nestboxes, gems, boulders and instruments. Dwarven adventurer sprites should show now.
1.1: Added Furniture Variations, updated floors, statues, fixed bug with glass walls.
1.0b: Fixed Tables
1.0: added graphics for all workshops, furniture and some items. Added Specific graphics for metal, wood and glass walls. And much much more.
0.2a: added a few workshop and tool sprites, barrels, large pots, vermin.
0.1a: Added among others, sprites for Hives, wells, Tracks, Trees and Water.